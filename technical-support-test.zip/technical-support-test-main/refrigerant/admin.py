from django.contrib import admin
from .models import Vessel

admin.site.register(Vessel)
