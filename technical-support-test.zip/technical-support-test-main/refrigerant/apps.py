from django.apps import AppConfig


class RefrigerantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'refrigerant'
